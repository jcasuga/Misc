
#include "contactList.h"

template<typename ValueType>
void visit(ValueType& data){

    cout << data << endl;

}

int menuChoice();

int main() {


    int menu, number;
    string search;
    contactList<string, int> list;

do
{
    menu = menuChoice();
    switch (menu)
    {
    case 1:
        cout << "What is the new contacts name?" << endl;
        cin >> search;
        cout << "What is their number (enter without dashes)" << endl;
        cin >> number;
        list.add(search, number);
        break;

    case 2: 
        cout << "What contact would you like to remove?" << endl;
        cin >> search;
        list.remove(search);
        break;

    case 3:
        list.traverse(visit);
        break;

    case 4:
        cout << "Enter contact name to search:";
        cin >> search;
        list.getValue(search);
        break;

    case 5:
        cout << "Select a contact to update" << endl;
        cin >> search;
        cout << "Input new number: " << endl;
        cin >> number;
        list.update(search, number);
        break;

    default:
        cout << "Please enter a valid choice!" << endl;
        break;
    }
} while (menu != 0);

    

return 0;
}

int menuChoice(){
    int choice;

    cout << " Contact List Manager" << endl;
    cout << "1. New Entry" << endl;
    cout << "2. Delete Entry"<< endl;
    cout << "3. View All Entries"<< endl;
    cout << "4. Search Entry"<< endl;
    cout << "5. Update Entry"<< endl;
    cout << "0. Exit"<< endl;
    cout << "Enter Your Choice: ";
    cin >> choice;

    return choice;

}