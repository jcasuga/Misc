#ifndef CONTACT_LIST_H
#define CONTACT_LIST_H

#include "dictionaryInterface.h"
#include "entry.h"
#include <iostream>
#include <memory>

using namespace std;
template<class KeyType, class ValueType>
class contactList : public DictionaryInterface<KeyType, ValueType>
{
private:
static const int DEFAULT_CAPACITY = 21; // Small capacity to test for a full dictionary
std::unique_ptr<Entry<KeyType, ValueType>[]> entries; // Array of dictionary entries
int entryCount; // Current count of dictionary entries
int maxEntries; // Maximum capacity of the dictionary
void destroyDictionary();
int findEntryIndex(int firstIndex, int lastIndex, const KeyType& searchKey) const;
public:
contactList();
contactList(int maxNumberOfEntries);
contactList(const contactList<KeyType, ValueType>& dictionary);
virtual ~contactList();
bool isEmpty() const;
int getNumberOfEntries() const;
bool add(const KeyType& searchKey, const ValueType& newValue) ;
bool remove(const KeyType& searchKey);
void clear();
ValueType getValue(const KeyType& searchKey) const ;
bool contains(const KeyType& searchKey) const;
/** Traverses the entries in this dictionary in sorted search-key order
and calls a given client function once for the value in each entry. */
bool update(const KeyType& searchKey, const ValueType& newValue);
void traverse(void visit(ValueType& value)) const;
int hashFunction(const KeyType& searchKey);
}; // end contactList
#include "contactList.cpp"



#endif