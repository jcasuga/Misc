#ifndef CONTACT_LIST_CPP
#define CONTACT_LIST_CPP
#include "contactList.h"

template<class KeyType, class ValueType>
contactList<KeyType, ValueType>::contactList() {
    
    entryCount = 0;
    maxEntries = DEFAULT_CAPACITY;

}

template<class KeyType, class ValueType>
contactList<KeyType, ValueType>::contactList(int maxNumberOfEntries): maxEntries(maxNumberOfEntries) {}

template<class KeyType, class ValueType>
contactList<KeyType, ValueType>::contactList(const contactList<KeyType, ValueType>& dictionary) {}

template<class KeyType, class ValueType>
contactList<KeyType, ValueType>::~contactList() {}

template<class KeyType, class ValueType>
void contactList<KeyType, ValueType>::destroyDictionary() {}

template<class KeyType, class ValueType>
int contactList<KeyType, ValueType>::findEntryIndex(int firstIndex, int lastIndex, const KeyType& searchKey) const {}

template<class KeyType, class ValueType>
bool contactList<KeyType, ValueType>::isEmpty() const{

    if(entryCount == 0){
        return true;
    }
    else{
        return false;
    }
}

template<class KeyType, class ValueType>
int contactList<KeyType, ValueType>::getNumberOfEntries() const {

    return entryCount;
}

template<class KeyType, class ValueType>
bool contactList<KeyType, ValueType>::add(const KeyType& searchKey, const ValueType& newValue) {
    int index;
    index = hashFunction(searchKey);
    bool canAdd = entryCount < maxEntries && index >= 1 && index <= entryCount + 1;

    if(canAdd){
        for(int i = entryCount; i >= index; i--){
            entries[i + 1] =  entries[i];
        }
        entries[index].setValue(newValue);
        entryCount++;
    }
    return canAdd;
}

template<class KeyType, class ValueType>
bool contactList<KeyType, ValueType>::remove(const KeyType& searchKey) {
    int index;
    index = hashFunction(searchKey);
    bool removable = index >= 1 && index <= entryCount;

    if(removable){
        for(int i = index; i < entryCount; i++){
            entries[i] = entries[i+1];
        }
        entryCount--;
    }

    return removable;
}

template<class KeyType, class ValueType>
void contactList<KeyType, ValueType>::clear() {
    entryCount = 0;
}

template<class KeyType, class ValueType>
ValueType contactList<KeyType, ValueType>::getValue(const KeyType& searchKey) const {

    int index;
    index = hashFunction(searchKey);
    return entries[index].getValue();
}

template<class KeyType, class ValueType>
bool contactList<KeyType, ValueType>::contains(const KeyType& searchKey) const {

    int index;
    index = hashFunction(searchKey);
    if(index == entries[index].getKey()){
        return true;
    }
    else{
        return false;
    }
}

template<class KeyType, class ValueType>
void contactList<KeyType, ValueType>::traverse(void visit(ValueType&)) const {

    for(int i = 0; i < entryCount; i++){

        cout << entries[i].getKey() << " " ;
        visit();
    }

}

template<class KeyType, class ValueType>
bool contactList<KeyType, ValueType>::update(const KeyType& searchKey, const ValueType& newValue){
    int index;
    index = hashFunction(searchKey);
    bool updated;
    bool replaceable = index >= 1 && index <= entryCount;
    if(replaceable){
        for(int i = 0; i <= entryCount; i++){
            if(index == entries[i].getKey()){
                entries[i].setValue(newValue);
                updated = true;
            }
        }
    }
    else{
        updated = false;
    }
    return updated;
}

template<class KeyType, class ValueType>
int contactList<KeyType, ValueType>::hashFunction(const KeyType& searchKey) {

    int hash = 0;

    for(int i = 0; searchKey[i] != '\0'; i++){
        hash += searchKey[i];
    }
    return hash % DEFAULT_CAPACITY;
}
#endif