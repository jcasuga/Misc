#ifndef ENTRY_CPP
#define ENTRY_CPP
#include "entry.h"

template<class KeyType, class ValueType>
Entry<KeyType, ValueType>::Entry(){}

template<class KeyType, class ValueType>
Entry<KeyType, ValueType>::Entry(const KeyType& newKey, const ValueType& newValue): key(newKey), value(newValue) {}

template<class KeyType, class ValueType>
ValueType Entry<KeyType, ValueType>::getValue() const{

    return value;

}

template<class KeyType, class ValueType>
KeyType Entry<KeyType, ValueType>::getKey() const{

    return key;

}

template<class KeyType, class ValueType>
void Entry<KeyType, ValueType>::setValue(const ValueType& newValue){

    value = newValue;

}

template<class KeyType, class ValueType>
void Entry<KeyType, ValueType>::setKey(const KeyType& searchKey){

    key = searchKey;
}

template<class KeyType, class ValueType>
bool Entry<KeyType, ValueType>::operator==(const Entry< KeyType,  ValueType>& rhs) const{

    if (key == rhs.getKey()){
        return true;
    }
    else{
        return false;
    }

}

template<class KeyType, class ValueType>
bool Entry<KeyType, ValueType>::operator>(const Entry< KeyType, ValueType>& rhs) const{

    if (value > rhs.getValue()){
        return true;
    }
    else{
        return false;
    }

}
#endif 